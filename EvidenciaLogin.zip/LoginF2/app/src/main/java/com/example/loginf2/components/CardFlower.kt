package com.example.loginf2.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.loginf2.navegation.NavRoutes
import com.example.loginf2.ui.theme.Shapes

@Composable
fun CardFlower(img: String, nombre: String, url:String, descripcion:String, navController: NavController) {
    Column(
        modifier = Modifier
            .border(3.dp, Color.Transparent, Shapes.small)
            .clip(Shapes.small)
            .background(Color.White)
            .clickable { navController.navigate(NavRoutes.Flower3.route)},
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = rememberAsyncImagePainter(img),
            contentDescription = "photo_fruta",
            modifier = Modifier
                .size(100.dp)
        )


        Text(
            text = nombre,
            modifier = Modifier
                .padding(10.dp)
                .background(Color.White),
            color = Color.Black,
            textAlign = TextAlign.Center
        )
    }
}