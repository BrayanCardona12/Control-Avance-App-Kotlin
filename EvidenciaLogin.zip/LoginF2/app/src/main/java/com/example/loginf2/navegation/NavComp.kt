package com.example.loginf2.navegation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType

import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.loginf2.models.Flowers
import com.example.loginf2.models.FlowersViewModel

import com.example.loginf2.models.MainViewModel
import com.example.loginf2.models.MoviesViewModel
import com.example.loginf2.screens.*

@Composable
fun Navegacion(
    isLoading: Boolean,
    siono: Boolean,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel
) {
    val contr = rememberNavController()
    NavHost(navController = contr, startDestination = NavRoutes.Login.route) {

        // val viewModel = MainViewModel()
        composable(NavRoutes.Home.route) {
            Flower1(contr)

//            Pant1(
//                contr,
//                algo = MainviewModel.state.value.algo,
//                email = MainviewModel.state.value.nombre,
//                img = MainviewModel.state.value.img,
//                onLoginClick = onLoginClick,
//                moviesViewModel = MoviesViewModel()
//            )
        }

        composable(NavRoutes.Insertar.route) { AddMovie(contr) }
        composable(NavRoutes.Flower1.route) { Flower1(contr) }
        composable(NavRoutes.Flower2.route) { Flower2(FlowersViewModel(), contr) }

        composable(
            NavRoutes.Flower3.route, arguments = listOf(
                navArgument("nombre") { type = NavType.StringType },
                navArgument("descripcion") { type = NavType.StringType },
                navArgument("url") { type = NavType.StringType },
                navArgument("img") { type = NavType.StringType }


            )
        )
        {
            Flower3(
                contr,
                nombre = it.arguments?.getString("nombre") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?: "",
                url = it.arguments?.getString("url") ?: "",
                img = it.arguments?.getString("img") ?: ""
            )
        }


        composable(NavRoutes.Flower4.route) { FormFlowers(contr) }




        composable(NavRoutes.Login.route) {
            if (siono) {
                LaunchedEffect(key1 = Unit) {
                    contr.navigate(
                        NavRoutes.Home.route


                    ) {

                        popUpTo(NavRoutes.Login.route) {
                            inclusive = true
                        }

                    }
                }
            } else {
                LoginScreen(
                    isLoading,
                    siono,
                    onLoginClick,
                    MainviewModel,
                    contr
                )
            }
        }


    }
}