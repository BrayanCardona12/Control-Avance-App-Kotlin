package com.example.loginf2.navegation

sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("Pant1")
    object Regresar : NavRoutes("LoginScreen")

    object HomeP : NavRoutes("Home2")

    object Login : NavRoutes("LoginScreen")
    object Insertar : NavRoutes("AddMovie")


    object Flower1 : NavRoutes("Flower1")


    object Flower2 : NavRoutes("Flower2/{nombre}/{descripcion}/{url}/{img}") {
        fun createRouteNueva(nombre:String, descripcion:String, url:String, img:String):String {
            return "Flower2/$nombre/$descripcion/$url/$img"
        }
    }
    object Flower3 : NavRoutes("Flower3/{nombre}/{descripcion}/{url}/{img}") {
        fun createNueva(nombre:String, descripcion:String, url:String, img:String):String {
            return "Flower3/$nombre/$descripcion/$url/$img"
        }
    }



    object Flower4 : NavRoutes("Flower4")




}









