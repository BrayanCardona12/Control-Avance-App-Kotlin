package com.example.loginf2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.loginf2.models.Flowers
import com.example.loginf2.models.Movies
import com.example.loginf2.navegation.NavRoutes
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun FormFlowers(navController: NavController) {
    var flowerNombre by remember { mutableStateOf("") }
    var flowerImg by remember { mutableStateOf("") }
    var flowerDesc by remember { mutableStateOf("") }
    var flowerUrl by remember { mutableStateOf("") }
    var validar by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.secondary)
            .padding(50.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "INSERT",
                modifier = Modifier
                    .fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = MaterialTheme.typography.h2.fontSize,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.primary
            )
            TextField(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Transparent),
                value = flowerNombre,
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                onValueChange = { flowerNombre = it },
                label = { Text(text = "Nombre:") })
            Spacer(modifier = Modifier.height(20.dp))


            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = flowerImg,
                onValueChange = { flowerImg = it },
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                label = { Text(text = "Img:") })
            Spacer(modifier = Modifier.height(20.dp))

            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = flowerDesc,
                onValueChange = { flowerDesc = it },
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                label = { Text(text = "Descripcion:") })
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = flowerUrl,
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                onValueChange = { flowerUrl = it },
                label = { Text(text = "Link:") })
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    if (flowerDesc == "" || flowerImg == "" || flowerNombre == "" || flowerUrl== "") {
                        validar = true
                    } else {
                        val flowers = Flowers(flowerImg, flowerNombre, flowerUrl, flowerDesc)

                        Firebase.firestore.collection("flowers").add(flowers)


                        navController.navigate(NavRoutes.Flower2.route)
                    }

                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "Añadir Fruta", color = MaterialTheme.colors.secondary)
            }

            if (validar) {
                Text(
                    text = "Error, por favor llena todos los campos",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colors.error,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    fontSize = 20.sp
                )
            }

        }
    }

}